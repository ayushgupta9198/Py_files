image1 = skimage.io.imread("")
plt.figure(figsize=(12,10))
skimage.io.imshow(image1)
# Load a random image from the images folder
# file_names = next(os.walk(IMAGE_DIR))[2]
# image = skimage.io.imread(os.path.join(IMAGE_DIR, random.choice(file_names)))
# Run detection
results = model.detect([image1], verbose=1)
# Visualize results
r = results[0]
visualize.display_instances(image1, r['rois'], r['masks'], r['class_ids'],
                            class_names, r['scores'])
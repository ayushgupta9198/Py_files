# find = "5636:命令\颁布\如下\ "

# print(type(find))

# for element in find:
#     if(element==":"):
#         find = find.replace(eind = find.replace(element, '')
# print(find)



data_path = './Eng-jap.txt'
# Vectorize the data.
input_texts = []
with open(data_path, 'r', encoding='utf-8') as f:
    lines = f.read().split('\n')
c =0
flg= 0
data = []
for line in lines:
	line1 = line
	if(flg%3==0):
		for element in line:
		    if(element==":"):
		        line1 = line.replace(element, '')
		        break
		    elif(element!=":"):
		        line1 = line.replace(element, '')
		line1 = ''.join([i for i in line1 if not i.isdigit()])
		data.append(line1)
	else:
		data.append(line1) 
	flg+=1

with open('./Eng-jap.txt', 'w') as f:
    for item in data:
        f.write("%s \n" % item)



          




        
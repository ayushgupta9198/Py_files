from googletrans import Translator  # Import Translator module from googletrans package
translator = Translator() # Create object of Translator.
translated = translator.translate('Please transfer 30 BTX to ANX') 
print(" Source Language:" + translated.src) 
# print(" Translated string:" + translated.text)
# translated = translator.translate('안녕하세요', src='ko') # Pass only source language
# translated = translator.translate('안녕하세요', dest='en') # Pass only destination language
# translated = translator.translate('안녕하세요', src='ko', dest='en') # Pass both source and destination
# translated = translator.translate('안녕하세요', src='ko', dest='ja')

translatedList = translator.translate(['Please transfer 30 BTX to ANX'], dest='hi')

for translated in translatedList:
           print(translated.origin, '->', translated.text)


# detected = translator.detect(' ')

# print('Detected Language:', detected.lang, ' with confidence: ', detected.confidence)

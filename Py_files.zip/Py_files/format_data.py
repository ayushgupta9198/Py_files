data_path = './en-ch_data.txt'

# Vectorize the data.
input_texts = []

with open(data_path, 'r', encoding='utf-8') as f:
    lines = f.read().split('\n')
c =0
data1 = []
data2 = []
for line in lines:
    if line[0].isdigit():
        # result = ''.join([i for i in line if not i.isdigit()])
        line1 = line.rsplit(":")  
        # print(line1[-1]) 
        data1.append(line1[-1])
    elif line[0] == ' ':
        continue
    else:   
        data2.append(line)
    
#     c += 1
#     if c == 20:
#         break


# # print("en ", len(data2), "chinese", len(data1))
# for i in range(len(data2)):
#     s = "%s\t%s" % (data2[i], data1[i])
#     print(s)
#     c += 1
#     if c == 20:
#         break

with open('en-ch_data-v2.txt', 'w') as f:
    for i in range(len(data1)):
        s = "%s\t%s\n" % (data2[i], data1[i])
        f.write(s)

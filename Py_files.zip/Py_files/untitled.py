import re
data_path = './en-ch_data.txt'
# Vectorize the data.
input_texts = []
with open(data_path, 'r', encoding='utf-8') as f:
    lines = f.read().split('\n')
c =0

en = []
ch = []
for line in lines:
	l = line.split('\t')
	ch.append (l[1])
	en.append(l[0])


with open('./en-ch_data_v1.txt', 'w') as f:
	for i in range(len(en)):
		s = "%s\t%s\n" % (ch[i],en[i])
		f.write(s)



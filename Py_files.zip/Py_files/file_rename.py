import os 
  
# Function to rename multiple files 
def main(): 
    i = 0
      
    for filename in os.listdir("/home/lenovo/Music/line_art/image123/"): 
        dst ="image." + str(i) + ".png"
        src ='/home/lenovo/Music/line_art/image123/'+ filename 
        dst ='//home/lenovo/Music/line_art/image321/'+ dst 
          
        # rename() function will 
        # rename all the files 
        os.rename(src, dst) 
        i += 1
  
# Driver Code 
if __name__ == '__main__': 
      
    # Calling main() function 
    main() 
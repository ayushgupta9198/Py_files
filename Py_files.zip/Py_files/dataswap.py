# 
import re
data_path = './eng-ko.txt'
# Vectorize the data.
input_texts = []
with open(data_path, 'r', encoding='utf-8') as f:
    lines = f.read().split('\n')
c =0

en = []
ch = []
for line in lines:
    l = line.split('\t')
    en.append(l[0])
    ch.append(l[1])


with open('./eng-ko_swap.txt', 'w') as f:
	for i in range(len(en)):
		s = "%s\t%s\n" % (ch[i],en[i])
		f.write(s)




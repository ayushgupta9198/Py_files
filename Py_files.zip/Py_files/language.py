
# english  to Koren translation
import goslate

from translate import Translator
text = 'Angelium is open website'
# kp = '안젤리움은 당신에게 암호 화폐 거래 플랫폼, 가상 현실, 채팅, 게임, 패션, 쇼핑, 교육, 음악 및 엔터테인먼트의 다양한 다른 형태를 제공 할 것입니다.'
from difflib import SequenceMatcher
print(text+"\n")
translator = Translator(to_lang='zh')
translation =  translator.translate(text)
print(translation+"\n")
# translator = Translator(to_lang='en')
# a=translator.translate(translation)
# print(a+"\n")






# # Koren to english translation

# # import goslate
# gs = goslate.Goslate()
# new_text = gs.translate(translation , 'ko')
# print(text)
# print(new_text)
# def similar(a, b):
#     return SequenceMatcher(None, a, b).ratio()
# print("the accuracy",similar(text, new_text))


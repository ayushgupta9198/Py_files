import os
import argparse
from PIL import Image
import cv2
DEFAULT_SIZE = (256,256)
def resize_image(input_dir, infile, output_dir="resized", size=DEFAULT_SIZE):
    outfile = os.path.splitext(infile)[0] + "_resized"
    extension = os.path.splitext(infile)[1]
    try:
        # img = Image.open(input_dir + '/' + infile)
        # img = img.resize((size[0], size[1]), Image.LANCZOS)
        img=cv2.imread(input_dir + '/' + infile)
        print('original image',img.shape,"#",infile)
        img=cv2.resize(img,DEFAULT_SIZE)
        print(img.shape)
        new_file = output_dir + "/" + outfile + extension
        cv2.imwrite(new_file,img)
    except IOError:
        print("unable to resize image {}".format(infile))
if __name__ == "__main__":
    dir = os.getcwd()
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--input_dir', help='Full Input Path')
    parser.add_argument('-o', '--output_dir', help='Full Output Path')
    parser.add_argument('-w', '--width', help='Resized Width')
    parser.add_argument('-t', '--height', help='Resized Height')
    args = parser.parse_args()
    if args.input_dir:
        input_dir = args.input_dir
    else:
        input_dir = dir + '/a'
    if args.output_dir:
        output_dir = args.output_dirs
    else:
        output_dir = dir + '/b'
    if args.width and args.height:
        size = (int(args.width), int(args.height))
    else:
        size = DEFAULT_SIZE
    if not os.path.exists(os.path.join(dir, output_dir)):
        os.mkdir(output_dir)
    try:
        for file in os.listdir(input_dir):
            resize_image(input_dir, file, output_dir, size=size)
    except OSError:
        print('file not found')
data_path = './en-ch_data.txt'
# Vectorize the data.
input_texts = []
with open(data_path, 'r', encoding='utf-8') as f:
    lines = f.read().split('\n')
c =0
data = []
for line in lines:
    line1 = line.rsplit("#",)
    data.append(line1[-1])
with open('./en-ch_data.txt', 'w') as f:
    for item in data:
        f.write("%s \n" % item)



        
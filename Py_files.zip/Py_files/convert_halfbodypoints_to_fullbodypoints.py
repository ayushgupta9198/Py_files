import json 
import cv2 
def read_file_new(path):
    with open(path,'r') as f:
        all_data = json.load(f)
    data = all_data['people'][0]['pose_keypoints_2d']
    x_list = []
    y_list = []
    z_list = []
    cnt = 0
    for i in [27,30,36,39]:
        data[i] = data[-3]
        if i==27 or i==36:
            # Ankle Points
            data[i+1] = data[i-2]+320
        else:
            # Foot Points
            data[i+1] = data[i-2]+380
        data[i+2] = 0.98
    all_data['people'][0]['pose_keypoints_2d'] = data
    
    with open(path, "w") as jsonFile:
        json.dump(all_data, jsonFile)
 
    return data
path = './json_output/_frame227_keypoints.json'
read_file_new(path)
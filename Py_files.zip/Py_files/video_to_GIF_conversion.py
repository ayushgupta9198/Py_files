from moviepy.editor import *
import moviepy.video.fx.all as vfx
clip = VideoFileClip('/home/ayush-ai/Music/video-generation/22.mp4')
clip = clip.resize(0.7)
sub = clip.subclip(1,4)
sub = sub.fx(vfx.crop, x1=115, x2=399, y1=0, y2=288)
clip2 = sub.speedx(final_duration=2)
clip3 = clip2.fx(vfx.time_mirror)
final = concatenate_videoclips([clip2, clip3])
final.to_gif("boomerang_like_gif3.gif", fps=25)